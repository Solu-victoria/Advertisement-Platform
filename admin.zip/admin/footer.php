<!-- start footer -->
		<div class="page-footer">
			<div class="page-footer-inner"> 2018 &copy; Spice Hotel Template By
				<a href="mailto:redstartheme@gmail.com" target="_top" class="makerCss">RedStar Theme</a>
			</div>
			<div class="scroll-to-top">
				<i class="icon-arrow-up"></i>
			</div>
		</div>
		<!-- end footer -->